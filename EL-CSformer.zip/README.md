# EL-CSformer

EL-CSformer 是论文 **《ELCSformer Based Compressed Sensing Imaging for Titanium Plate Eddy Current Testing》** 中提出的压缩感知成像模型，用于实现钛板涡流检测的快速压缩感知成像。


## 主要功能

- 实现涡流检测的快速压缩感知成像
- 支持模型训练、验证和测试
- 支持 TensorBoard 训练日志记录
- 支持多 GPU 训练（代码会自动检测可用 GPU）
- 支持余弦退火学习率调整
- 支持保存最佳 PSNR / SSIM 模型

## 环境要求

- Windows
- Python 3.10
- NVIDIA GPU + CUDA
- PyTorch
- 其他依赖：`numpy`、`tqdm`、`tensorboardX`、`matplotlib`

## 安装依赖

建议先创建虚拟环境：

```bat
python -m venv .venv
.venv\Scripts\activate
```

然后安装 PyTorch。**不要直接随便 `pip install torch`，建议先打开 PyTorch 官网，按你的 CUDA 版本选择安装命令：**

https://pytorch.org/get-started/locally/

安装完 PyTorch 后，再安装其他依赖：

```bat
pip install numpy tqdm tensorboardX matplotlib
```

如果运行时报 `ModuleNotFoundError`，按提示安装缺少的包即可。例如：

```bat
pip install 包名
```

## 数据准备


主要参数：

| 参数 | 含义 |
|---|---|
| `--data_path` | 训练数据文件夹 |
| `--valdata_path` | 验证数据文件夹 |
| `--testdata_path` | 测试数据文件夹 |
| `--dataset` | 数据集名称，当前示例是 `bsd300`，按你的实际数据修改 |

原始 `train.bat` 里类似 `G:/CS_Former/...` 的路径是你电脑上的本地路径，必须改成自己的路径。

## 训练

### 第一次训练


修改 `train.bat` 中的数据路径：

```bat
--data_path 你的训练数据路径
--valdata_path 你的验证数据路径
```

在 PyCharm 终端中运行：

```bat
train.bat
```

或者直接运行：

```bat
python train.py --gen_model CSformer --exp_name CSformer_cs50 --cs_ratio 50 --img_size 64 --bottom_width 8 --max_iter 34000 --g_lr 5e-4 --gen_batch_size 10 --eval_batch_size 10 --gf_dim 128 --val_freq 2 --print_freq 10 --g_window_size 8 --num_workers 1 --optimizer adam --beta1 0.9 --beta2 0.999 --init_type xavier_uniform --g_depth 5,5,5,5 --datarange -11 --train_patch_size 128 --rec_loss_type l2 --dataset bsd300 --data_path 你的训练数据路径 --valdata_path 你的验证数据路径
```

### 恢复训练

如果你想从上次的 checkpoint 继续训练，保留 `--load_path`，并让它指向你的日志目录，例如：

```bat
--load_path ./logs/CSformer_cs50/
```

代码会去找：

```text
./logs/CSformer_cs50/Model/checkpoint.pth
```

注意大小写：代码里写的是 `Model`。如果你的实际文件夹叫 `model`，请改成实际名称，或者把文件夹名改成 `Model`。

### 训练输出

训练结果默认保存在：

```text
logs/<exp_name>/
```

里面通常包括：

- 日志文件
- TensorBoard 日志
- checkpoint 文件
- `training_loss.jpg` 损失曲线

## 测试

修改 `test.bat`，主要改这几个参数：

```bat
python eval.py ^
--cs_ratio 50 ^
--exp_name CSformer_cs50 ^
--load_path ./logs/CSformer_cs50/Model/checkpoint_best.pth ^
--testdata_path 你的测试数据路径
```

注意：

- `--cs_ratio` 要和训练时一致。
- `--exp_name` 建议和训练时的实验名一致。
- `--load_path` 必须是一个实际存在的 `.pth` 文件，不能是文件夹。
- 如果实际文件名不是 `checkpoint_best.pth`，请改成你实际的文件名。
- 注意 `Model` / `model` 大小写，以你电脑上的实际文件夹为准。

然后运行：

```bat
test.bat
```

测试日志默认保存在：

```text
logs_eval/<exp_name>/
```

## 主要参数说明

| 参数 | 作用 | 示例 |
|---|---|---|
| `--gen_model` | 模型名称，对应 `models/` 下的模型文件 | `CSformer` |
| `--exp_name` | 实验名称，决定日志保存文件夹 | `CSformer_cs50` |
| `--cs_ratio` | 压缩感知采样率 | `4`、`10`、`25`、`30`、`40`、`50` |
| `--g_lr` | 生成器学习率 | `5e-4` |
| `--gen_batch_size` | 训练批大小 | `10` |
| `--eval_batch_size` | 验证/测试批大小 | `10` |
| `--gf_dim` | 模型特征维度 | `128` |
| `--val_freq` | 每隔多少个 epoch 验证一次 | `2` |
| `--g_window_size` | Transformer 窗口大小 | `8` |
| `--g_depth` | Transformer 各阶段深度 | `5,5,5,5` |
| `--train_patch_size` | 训练图像块大小 | `128` |
| `--rec_loss_type` | 重建损失类型 | `l2` |
| `--max_iter` | 最大训练迭代次数 | `34000` |
| `--load_path` | 恢复训练目录，或测试时的 `.pth` 文件 | `./logs/CSformer_cs50/` |

`train.py` 中有一个 `ratio_dict`，目前支持：

```text
 4, 10, 25, 30, 40, 50
```

所以 `--cs_ratio` 建议使用这些值。

## 目录结构

```text
.
├─ train.py                 # 训练入口
├─ test.py                  # 测试入口
├─ cfg.py                   # 参数解析
├─ functions.py             # 训练、验证、测试函数
├─ datasets.py              # 数据集加载
├─ models/                  # 模型代码
├─ loss/                    # 损失函数
├─ utils/                   # 工具函数
├─ train.bat                # Windows 训练脚本
├─ test.bat                 # Windows 测试脚本
├─ .gitignore
└─ README.md
```

## 常见问题

### 1. 第一次训练报错找不到 checkpoint

检查 `train.bat` 里是否还有：

```bat
--load_path ...
```

第一次训练请删掉这一行。

### 2. 测试时报错找不到 `.pth`

检查：

- `--load_path` 是否指向一个真实存在的 `.pth` 文件；
- 文件名是不是 `checkpoint_best.pth`；
- 文件夹是 `Model` 还是 `model`，大小写要一致；
- 是否和训练时的 `--cs_ratio` 一致。

### 3. 显存不足

可以尝试减小：

```bat
--gen_batch_size 10
--eval_batch_size 10
--train_patch_size 128
```

比如先把 `gen_batch_size` 改成 `4` 或 `2`。

### 4. 训练只跑到 100 轮就停了

`train.py` 里有这一行：

```python
if epoch == 100:
    break
```

这表示第 100 个 epoch 后会强制停止。如果你不想只跑 100 轮，需要删掉这一行，或者把 `100` 改成你想要的值。


## 许可证

本项目采用 MIT 许可证。

## 引用

如果本项目对你有帮助，请引用论文：

> EL-CSformer Based Compressed Sensing Imaging for Titanium Plate Eddy Current Testing