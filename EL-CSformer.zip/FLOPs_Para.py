from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from fvcore.nn import FlopCountAnalysis, parameter_count
import cfg
import torch
import torch.nn as nn
import datasets
torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = True
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
# 设置采样率、更换模型、g、r
def main():
    # 解析命令行参数，从命令行中读取参数，以控制程序行为
    args = cfg.parse_args()
    # 设置随机种子，保证结果可重复性
    #torch.cuda.manual_seed(args.random_seed)

    # Get Sensing_matrix
    cs_ratio = 50
    ratio_dict = {1: 3, 4: 11, 10: 26, 25: 64, 30: 77, 40: 103, 50: 128}
    n_input = ratio_dict[cs_ratio]  # 从命令行中解析出参数，用于对于字典中的键
    args.n_input = n_input  # 用于存储根据args.cs_ratio从字典中检索到的值
    # 根据压缩比率，计算输入特征的数量，并更新参数

    # import network 生成初始化模型
    exec('import '+'models.'+args.gen_model)  # 动态执行代码：import models.args.gen_model
    gen_net = eval('models.'+args.gen_model+'.CSformer')(args).cuda()  # 动态执行代码，字符串动态构成



    # 打印模型和数据集信息
    print(f'model param {(sum(param.numel() for param in  gen_net.parameters()))/1e6}M')

    # 多gpu支持，检测可用的gpu并适用它们进行训练
    gpu_ids = [i for i in range(int(torch.cuda.device_count()))]
    print('gpu ids:',gpu_ids)
    gen_net = torch.nn.DataParallel(gen_net.to("cuda:0"), device_ids=gpu_ids)

    input_tensor = torch.randn(10, 1, 128, 128).to(device)
    flops = FlopCountAnalysis(gen_net, input_tensor)
    FLOPs = flops.total() / 10 ** 9
    print('FLOPs : ', FLOPs, 'G')

    # params 是一个字典，其键“module”对应的值为模型总参数，
    # 其他键对应值为某模块或层的参数量,用get方法获得键对应的值
    #print(f"Total Parameters: {sum(params.values())}")
    params = parameter_count(gen_net)
    para = params.get('module')
    print(f"Total Parameters: ", para/1000000, 'M')
    print(f"Model 1 parameters: {count_parameters(gen_net) / 1e6:.6f}M")


if __name__ == '__main__':
    main()