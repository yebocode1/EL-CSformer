python eval.py ^
--cs_ratio 4 ^
--exp_name EAA_LDMLP_cs4 ^
--load_path ./logs/EAA_LDMLP_cs4/model/checkpoint_best.pth ^
--testdata_path G:/CS_Former/pythonProject/csformer/Ect_data/test365
